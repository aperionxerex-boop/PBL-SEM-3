import { describe, expect, it } from "vitest";

import {
  buildNetworkText,
  calculateHealth,
  getDiagnostics,
  getHealthStatus,
  validateConfigurationCounts,
  type AccessPoint,
} from "@/lib/network-model";

const baseline: AccessPoint = {
  id: "AP-01",
  signalStrength: 50,
  bandwidth: 50,
  latency: 50,
  interference: 60,
  activeUsers: 50,
};

describe("network model rules", () => {
  it("multiplies the documented weighted health factors and clamps the result", () => {
    expect(
      calculateHealth({
        ...baseline,
        signalStrength: 10,
        bandwidth: 10,
        latency: 90,
        interference: 90,
        activeUsers: 90,
      }),
    ).toBe(24);
    expect(calculateHealth({ ...baseline, signalStrength: 100, bandwidth: 100, latency: 0, interference: 0, activeUsers: 0 })).toBe(100);
    expect(calculateHealth({ ...baseline, activeUsers: 150 })).toBe(0);
  });

  it("uses the documented GOOD, WARNING and CRITICAL score boundaries", () => {
    expect(getHealthStatus(70)).toBe("GOOD");
    expect(getHealthStatus(69.99)).toBe("WARNING");
    expect(getHealthStatus(40)).toBe("WARNING");
    expect(getHealthStatus(39.99)).toBe("CRITICAL");
  });

  it("flags signal strictly below 50 as weak", () => {
    expect(getDiagnostics({ ...baseline, signalStrength: 49 }).map((issue) => issue.code)).toContain("weak-signal");
    expect(getDiagnostics({ ...baseline, signalStrength: 50 }).map((issue) => issue.code)).not.toContain("weak-signal");
  });

  it("flags latency strictly above 50 as high", () => {
    expect(getDiagnostics({ ...baseline, latency: 51 }).map((issue) => issue.code)).toContain("high-latency");
    expect(getDiagnostics({ ...baseline, latency: 50 }).map((issue) => issue.code)).not.toContain("high-latency");
  });

  it("flags interference strictly above 60 as high", () => {
    expect(getDiagnostics({ ...baseline, interference: 61 }).map((issue) => issue.code)).toContain("high-interference");
    expect(getDiagnostics({ ...baseline, interference: 60 }).map((issue) => issue.code)).not.toContain("high-interference");
  });

  it("flags active user counts strictly above 50 as high", () => {
    expect(getDiagnostics({ ...baseline, activeUsers: 51 }).map((issue) => issue.code)).toContain("high-user-load");
    expect(getDiagnostics({ ...baseline, activeUsers: 50 }).map((issue) => issue.code)).not.toContain("high-user-load");
  });

  it("accepts only 2–20 access points and 1–50 connections", () => {
    expect(validateConfigurationCounts(2, 1)).toBeNull();
    expect(validateConfigurationCounts(20, 50)).toBeNull();
    expect(validateConfigurationCounts(1, 1)).not.toBeNull();
    expect(validateConfigurationCounts(21, 1)).not.toBeNull();
    expect(validateConfigurationCounts(2, 0)).not.toBeNull();
    expect(validateConfigurationCounts(2, 51)).not.toBeNull();
  });

  it("exports configured access points and links in the required row order", () => {
    const text = buildNetworkText({
      accessPoints: [baseline],
      connections: [
        { id: "LINK-01", ap1: "AP-01", ap2: "AP-02", distance: 18, latency: 4, interference: 7, signal: 88, users: 11 },
      ],
    });

    expect(text.split("\n")).toEqual(["1 1", "AP-01 50 50 50 60 50 0.00", "AP-01 AP-02 18 4 7 88 11"]);
  });
});