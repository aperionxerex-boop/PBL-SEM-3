export type HealthStatus = "GOOD" | "WARNING" | "CRITICAL";

export interface AccessPoint {
  id: string;
  signalStrength: number;
  bandwidth: number;
  latency: number;
  interference: number;
  activeUsers: number;
}

export interface NetworkConnection {
  id: string;
  ap1: string;
  ap2: string;
  distance: number;
  latency: number;
  interference: number;
  signal: number;
  users: number;
}

export interface NetworkModel {
  accessPoints: AccessPoint[];
  connections: NetworkConnection[];
}

export interface DiagnosticIssue {
  code: "weak-signal" | "high-latency" | "high-interference" | "high-user-load";
  title: string;
  detail: string;
  severity: "warning" | "critical";
}

export function calculateHealth(ap: AccessPoint): number {
  const score =
    ap.signalStrength *
    0.3 *
    (ap.bandwidth * 0.2) *
    ((100 - ap.latency) * 0.2) *
    ((100 - ap.interference) * 0.2) *
    ((100 - ap.activeUsers) * 0.1);

  return Math.max(0, Math.min(100, Number.isFinite(score) ? score : 0));
}

export function getHealthStatus(score: number): HealthStatus {
  if (score >= 70) return "GOOD";
  if (score >= 40) return "WARNING";
  return "CRITICAL";
}

export function getDiagnostics(ap: AccessPoint): DiagnosticIssue[] {
  const issues: DiagnosticIssue[] = [];

  if (ap.signalStrength < 50) {
    issues.push({
      code: "weak-signal",
      title: "Weak Signal",
      detail: `Signal strength is ${ap.signalStrength}%, below the 50% threshold.`,
      severity: ap.signalStrength < 25 ? "critical" : "warning",
    });
  }
  if (ap.latency > 50) {
    issues.push({
      code: "high-latency",
      title: "High Latency",
      detail: `Latency is ${ap.latency} ms, above the 50 ms threshold.`,
      severity: ap.latency > 75 ? "critical" : "warning",
    });
  }
  if (ap.interference > 60) {
    issues.push({
      code: "high-interference",
      title: "High Interference",
      detail: `Interference is ${ap.interference}%, above the 60% threshold.`,
      severity: ap.interference > 80 ? "critical" : "warning",
    });
  }
  if (ap.activeUsers > 50) {
    issues.push({
      code: "high-user-load",
      title: "High User Load",
      detail: `${ap.activeUsers} active users exceeds the 50-user threshold.`,
      severity: ap.activeUsers > 80 ? "critical" : "warning",
    });
  }

  return issues;
}

export function validateConfigurationCounts(apCount: number, connectionCount: number): string | null {
  if (!Number.isInteger(apCount) || apCount < 2 || apCount > 20) {
    return "Access Points must be a whole number from 2 to 20.";
  }
  if (!Number.isInteger(connectionCount) || connectionCount < 1 || connectionCount > 50) {
    return "Connections must be a whole number from 1 to 50.";
  }
  return null;
}

export function createSampleNetwork(): NetworkModel {
  return {
    accessPoints: [
      { id: "AP-01", signalStrength: 82, bandwidth: 76, latency: 18, interference: 22, activeUsers: 24 },
      { id: "AP-02", signalStrength: 74, bandwidth: 68, latency: 28, interference: 34, activeUsers: 37 },
      { id: "AP-03", signalStrength: 43, bandwidth: 51, latency: 62, interference: 68, activeUsers: 56 },
      { id: "AP-04", signalStrength: 67, bandwidth: 61, latency: 45, interference: 51, activeUsers: 48 },
      { id: "AP-05", signalStrength: 28, bandwidth: 39, latency: 79, interference: 84, activeUsers: 87 },
    ],
    connections: [
      { id: "LINK-01", ap1: "AP-01", ap2: "AP-02", distance: 42, latency: 12, interference: 18, signal: 84, users: 16 },
      { id: "LINK-02", ap1: "AP-01", ap2: "AP-03", distance: 68, latency: 28, interference: 33, signal: 61, users: 22 },
      { id: "LINK-03", ap1: "AP-02", ap2: "AP-03", distance: 36, latency: 17, interference: 27, signal: 72, users: 19 },
      { id: "LINK-04", ap1: "AP-02", ap2: "AP-04", distance: 51, latency: 20, interference: 24, signal: 78, users: 21 },
      { id: "LINK-05", ap1: "AP-03", ap2: "AP-05", distance: 73, latency: 46, interference: 62, signal: 42, users: 31 },
      { id: "LINK-06", ap1: "AP-04", ap2: "AP-05", distance: 44, latency: 35, interference: 49, signal: 56, users: 28 },
    ],
  };
}

export function buildNetworkText(network: NetworkModel): string {
  const accessPointLines = network.accessPoints.map((ap) =>
    [
      ap.id,
      ap.signalStrength,
      ap.bandwidth,
      ap.latency,
      ap.interference,
      ap.activeUsers,
      calculateHealth(ap).toFixed(2),
    ].join(" "),
  );
  const connectionLines = network.connections.map((connection) =>
    [
      connection.ap1,
      connection.ap2,
      connection.distance,
      connection.latency,
      connection.interference,
      connection.signal,
      connection.users,
    ].join(" "),
  );

  return [
    `${network.accessPoints.length} ${network.connections.length}`,
    ...accessPointLines,
    ...connectionLines,
  ].join("\n");
}