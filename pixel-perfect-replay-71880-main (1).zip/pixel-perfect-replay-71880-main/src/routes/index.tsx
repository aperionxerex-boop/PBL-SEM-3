import { createFileRoute } from "@tanstack/react-router";
import { NetworkOptimizer } from "@/components/network-optimizer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Campus WiFi Mesh Optimizer | Network Health Simulation" },
      { name: "description", content: "Model a campus Wi-Fi mesh, calculate access point health, inspect diagnostics, and export the configured network." },
      { property: "og:title", content: "Campus WiFi Mesh Optimizer" },
      { property: "og:description", content: "A Phase 1 network modeling and health-check simulation for campus Wi-Fi meshes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NetworkOptimizer,
});
