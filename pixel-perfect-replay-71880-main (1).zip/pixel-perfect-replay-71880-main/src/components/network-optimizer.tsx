import { useEffect, useMemo, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import {
  Activity,
  AlertTriangle,
  Antenna,
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  Download,
  Gauge,
  Layers3,
  LayoutDashboard,
  Link2,
  Map as MapIcon,
  Network,
  Radio,
  Settings2,
  ShieldAlert,
  ShieldCheck,
  Signal,
  SlidersHorizontal,
  Wifi,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  buildNetworkText,
  calculateHealth,
  createSampleNetwork,
  getDiagnostics,
  getHealthStatus,
  validateConfigurationCounts,
  type AccessPoint,
  type DiagnosticIssue,
  type HealthStatus,
  type NetworkConnection,
  type NetworkModel,
} from "@/lib/network-model";

type ViewKey = "dashboard" | "configure" | "access-points" | "topology" | "diagnostics" | "reports" | "about";

const STORAGE_KEY = "campus-wifi-mesh-optimizer-v1";

const navigation: { key: ViewKey; label: string; icon: typeof LayoutDashboard }[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "configure", label: "Configure Network", icon: Settings2 },
  { key: "access-points", label: "Access Points", icon: Antenna },
  { key: "topology", label: "Topology Visualization", icon: Network },
  { key: "diagnostics", label: "Network Diagnostics", icon: ShieldAlert },
  { key: "reports", label: "Reports & Export", icon: Download },
  { key: "about", label: "About Project", icon: Layers3 },
];

function isNetworkModel(value: unknown): value is NetworkModel {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<NetworkModel>;
  return (
    Array.isArray(candidate.accessPoints) &&
    Array.isArray(candidate.connections) &&
    validateConfigurationCounts(candidate.accessPoints.length, candidate.connections.length) === null &&
    candidate.accessPoints.every(
      (ap) =>
        typeof ap.id === "string" &&
        [ap.signalStrength, ap.bandwidth, ap.latency, ap.interference, ap.activeUsers].every(Number.isFinite),
    ) &&
    candidate.connections.every(
      (connection) =>
        typeof connection.id === "string" &&
        typeof connection.ap1 === "string" &&
        typeof connection.ap2 === "string" &&
        [connection.distance, connection.latency, connection.interference, connection.signal, connection.users].every(
          Number.isFinite,
        ),
    )
  );
}

function StatusPill({ status }: { status: HealthStatus }) {
  const Icon = status === "GOOD" ? CircleCheck : status === "WARNING" ? CircleAlert : ShieldAlert;
  return (
    <span className={`status-pill status-pill--${status.toLowerCase()}`}>
      <Icon aria-hidden="true" />
      {status}
    </span>
  );
}

function NumberField({
  label,
  value,
  min = 0,
  max,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min?: number;
  max?: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="field-wrap">
      <span className="field-label">{label}</span>
      <span className="field-control-wrap">
        <input
          className="field-input"
          type="number"
          min={min}
          max={max}
          step="any"
          value={value}
          onChange={(event) => onChange(Number(event.currentTarget.value))}
        />
        {suffix ? <span className="field-suffix">{suffix}</span> : null}
      </span>
    </label>
  );
}

function MetricTile({
  label,
  value,
  note,
  icon: Icon,
  tone = "blue",
  trend,
}: {
  label: string;
  value: string | number;
  note: ReactNode;
  icon: typeof Activity;
  tone?: "blue" | "good" | "warning" | "critical";
  trend?: "up" | "down";
}) {
  const TrendIcon = trend === "up" ? ArrowUpRight : ArrowDownRight;
  return (
    <article className="metric-tile">
      <div className="metric-tile-top">
        <span className={`metric-icon metric-icon--${tone}`}>
          <Icon aria-hidden="true" />
        </span>
        {trend ? <TrendIcon className="metric-trend" aria-hidden="true" /> : null}
      </div>
      <p className="metric-label">{label}</p>
      <div className="metric-value-row">
        <strong className="metric-value">{value}</strong>
        <span className="metric-note">{note}</span>
      </div>
    </article>
  );
}

function PanelHeading({
  eyebrow,
  title,
  detail,
  action,
}: {
  eyebrow?: string;
  title: string;
  detail?: string;
  action?: ReactNode;
}) {
  return (
    <div className="panel-heading">
      <div className="min-w-0">
        {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
        <h2 className="panel-title">{title}</h2>
        {detail ? <p className="panel-detail">{detail}</p> : null}
      </div>
      {action ? <div className="panel-action">{action}</div> : null}
    </div>
  );
}

function IssueBadge({ issue }: { issue: DiagnosticIssue }) {
  return (
    <span className={`issue-badge issue-badge--${issue.severity}`}>
      <AlertTriangle aria-hidden="true" />
      {issue.title}
    </span>
  );
}

function HealthDistribution({
  good,
  warning,
  critical,
  total,
}: {
  good: number;
  warning: number;
  critical: number;
  total: number;
}) {
  const portions = total > 0 ? [good / total, warning / total, critical / total] : [0, 0, 0];
  const circumference = 100;
  let dashOffset = 0;
  const segments = portions.map((portion, index) => {
    const length = portion * circumference;
    const segment = { length, offset: dashOffset, className: ["health-ring-good", "health-ring-warning", "health-ring-critical"][index] };
    dashOffset += length;
    return segment;
  });

  return (
    <div className="distribution-layout">
      <div className="health-ring-wrap" aria-label={`${good} good, ${warning} warning, ${critical} critical access points`}>
        <svg className="health-ring" viewBox="0 0 120 120" role="img" aria-hidden="true">
          <circle className="health-ring-track" cx="60" cy="60" r="42" pathLength={circumference} />
          {segments.map((segment, index) => (
            <circle
              key={segment.className ?? index}
              className={segment.className}
              cx="60"
              cy="60"
              r="42"
              pathLength={circumference}
              strokeDasharray={`${segment.length} ${circumference - segment.length}`}
              strokeDashoffset={-segment.offset}
            />
          ))}
        </svg>
        <div className="health-ring-center">
          <strong>{total}</strong>
          <span>Access points</span>
        </div>
      </div>
      <div className="distribution-legend">
        {[
          { label: "Good", count: good, className: "legend-dot-good", score: "70–100" },
          { label: "Warning", count: warning, className: "legend-dot-warning", score: "40–69" },
          { label: "Critical", count: critical, className: "legend-dot-critical", score: "0–39" },
        ].map((item) => (
          <div className="legend-row" key={item.label}>
            <span className={`legend-dot ${item.className}`} />
            <span className="legend-label">{item.label}</span>
            <strong className="legend-count">{item.count}</strong>
            <span className="legend-score">{item.score}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function HealthBar({ ap, score, status }: { ap: AccessPoint; score: number; status: HealthStatus }) {
  return (
    <div className="health-bar-row">
      <span className="health-bar-name">{ap.id}</span>
      <div className="health-bar-track" aria-label={`${ap.id} health score ${score.toFixed(1)}`}>
        <div className={`health-bar-fill health-bar-fill--${status.toLowerCase()}`} style={{ width: `${score}%` }} />
      </div>
      <strong className={`health-bar-score health-text--${status.toLowerCase()}`}>{score.toFixed(0)}</strong>
      <StatusPill status={status} />
    </div>
  );
}

function TopologyCanvas({
  accessPoints,
  connections,
  selectedApId,
  selectedConnectionId,
  getStatus,
  onSelectAp,
  onSelectConnection,
}: {
  accessPoints: AccessPoint[];
  connections: NetworkConnection[];
  selectedApId: string;
  selectedConnectionId: string;
  getStatus: (ap: AccessPoint) => HealthStatus;
  onSelectAp: (id: string) => void;
  onSelectConnection: (id: string) => void;
}) {
  const positions = useMemo(() => {
    const columns = Math.ceil(Math.sqrt(accessPoints.length * 1.3));
    const rows = Math.ceil(accessPoints.length / columns);
    return new Map(
      accessPoints.map((ap, index) => {
        const column = index % columns;
        const row = Math.floor(index / columns);
        return [
          ap.id,
          {
            x: ((column + 1) * 800) / (columns + 1),
            y: ((row + 1) * 430) / (rows + 1),
          },
        ];
      }),
    );
  }, [accessPoints]);

  return (
    <div className="topology-canvas">
      <div className="topology-key">
        <span><i className="legend-dot-good" /> Good</span>
        <span><i className="legend-dot-warning" /> Warning</span>
        <span><i className="legend-dot-critical" /> Critical</span>
        <span className="topology-key-line" /> Mesh connection
      </div>
      <svg className="topology-svg" viewBox="0 0 800 430" role="group" aria-label="Interactive access point mesh topology">
        {connections.map((connection) => {
          const from = positions.get(connection.ap1);
          const to = positions.get(connection.ap2);
          if (!from || !to) return null;
          const selected = connection.id === selectedConnectionId;
          return (
            <g
              key={connection.id}
              className="topology-edge"
              role="button"
              tabIndex={0}
              aria-label={`Connection ${connection.id}: ${connection.ap1} to ${connection.ap2}`}
              aria-pressed={selected}
              onClick={() => onSelectConnection(connection.id)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelectConnection(connection.id);
                }
              }}
            >
              <line
                className={selected ? "edge-line edge-line--selected" : "edge-line"}
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
              />
              <line className="edge-hit-area" x1={from.x} y1={from.y} x2={to.x} y2={to.y} />
              <text className="edge-label" x={(from.x + to.x) / 2} y={(from.y + to.y) / 2 - 8}>
                {connection.id}
              </text>
            </g>
          );
        })}
        {accessPoints.map((ap) => {
          const point = positions.get(ap.id);
          if (!point) return null;
          const status = getStatus(ap);
          return (
            <g
              key={ap.id}
              className={`topology-node topology-node--${status.toLowerCase()}${ap.id === selectedApId ? " topology-node--selected" : ""}`}
              role="button"
              tabIndex={0}
              aria-label={`${ap.id}, ${status}, health ${calculateHealth(ap).toFixed(1)}`}
              aria-pressed={ap.id === selectedApId}
              transform={`translate(${point.x} ${point.y})`}
              onClick={() => onSelectAp(ap.id)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelectAp(ap.id);
                }
              }}
            >
              <circle className="node-halo" r="38" />
              <circle className="node-disc" r="29" />
              <text className="node-signal" y="-2">{calculateHealth(ap).toFixed(0)}</text>
              <text className="node-id" y="48">{ap.id}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export function NetworkOptimizer() {
  const [network, setNetwork] = useState<NetworkModel>(() => createSampleNetwork());
  const [activeView, setActiveView] = useState<ViewKey>("dashboard");
  const [selectedApId, setSelectedApId] = useState("AP-01");
  const [selectedConnectionId, setSelectedConnectionId] = useState("LINK-01");
  const [pendingApCount, setPendingApCount] = useState("5");
  const [pendingConnectionCount, setPendingConnectionCount] = useState("6");
  const [formError, setFormError] = useState("");
  const [formMessage, setFormMessage] = useState("");
  const [apIdDrafts, setApIdDrafts] = useState<Record<string, string>>({});
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (isNetworkModel(parsed)) {
          setNetwork(parsed);
          setPendingApCount(String(parsed.accessPoints.length));
          setPendingConnectionCount(String(parsed.connections.length));
        }
      }
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
    setIsReady(true);
  }, []);

  useEffect(() => {
    if (!isReady) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(network));
    } catch {
      setFormMessage("This browser could not save the current network locally.");
    }
  }, [isReady, network]);

  useEffect(() => {
    if (!network.accessPoints.some((ap) => ap.id === selectedApId)) {
      setSelectedApId(network.accessPoints[0]?.id ?? "");
    }
    if (!network.connections.some((connection) => connection.id === selectedConnectionId)) {
      setSelectedConnectionId(network.connections[0]?.id ?? "");
    }
  }, [network, selectedApId, selectedConnectionId]);

  const scoredAccessPoints = useMemo(
    () =>
      network.accessPoints.map((ap) => {
        const score = calculateHealth(ap);
        return { ap, score, status: getHealthStatus(score), issues: getDiagnostics(ap) };
      }),
    [network.accessPoints],
  );
  const healthCounts = useMemo(
    () => ({
      good: scoredAccessPoints.filter((item) => item.status === "GOOD").length,
      warning: scoredAccessPoints.filter((item) => item.status === "WARNING").length,
      critical: scoredAccessPoints.filter((item) => item.status === "CRITICAL").length,
    }),
    [scoredAccessPoints],
  );
  const averageHealth =
    scoredAccessPoints.reduce((sum, item) => sum + item.score, 0) / Math.max(scoredAccessPoints.length, 1);
  const overallStatus = getHealthStatus(averageHealth);
  const totalUsers = network.accessPoints.reduce((sum, ap) => sum + ap.activeUsers, 0);
  const allIssues = scoredAccessPoints.flatMap((item) => item.issues.map((issue) => ({ ap: item.ap, issue })));
  const selectedAp = network.accessPoints.find((ap) => ap.id === selectedApId) ?? network.accessPoints[0];
  const selectedConnection = network.connections.find((connection) => connection.id === selectedConnectionId);

  function updateAccessPoint(apId: string, field: keyof AccessPoint, value: number) {
    setNetwork((current) => ({
      ...current,
      accessPoints: current.accessPoints.map((ap) => (ap.id === apId ? { ...ap, [field]: value } : ap)),
    }));
  }

  function renameAccessPoint(oldId: string, draft: string) {
    const nextId = draft.trim();
    if (!nextId || network.accessPoints.some((ap) => ap.id !== oldId && ap.id.toLowerCase() === nextId.toLowerCase())) {
      setFormError("Access Point IDs must be unique and cannot be blank.");
      setApIdDrafts((drafts) => ({ ...drafts, [oldId]: oldId }));
      return;
    }
    setFormError("");
    setNetwork((current) => ({
      accessPoints: current.accessPoints.map((ap) => (ap.id === oldId ? { ...ap, id: nextId } : ap)),
      connections: current.connections.map((connection) => ({
        ...connection,
        ap1: connection.ap1 === oldId ? nextId : connection.ap1,
        ap2: connection.ap2 === oldId ? nextId : connection.ap2,
      })),
    }));
    setSelectedApId((current) => (current === oldId ? nextId : current));
    setApIdDrafts((drafts) => {
      const nextDrafts = { ...drafts };
      delete nextDrafts[oldId];
      nextDrafts[nextId] = nextId;
      return nextDrafts;
    });
  }

  function updateConnection(connectionId: string, field: keyof NetworkConnection, value: string | number) {
    setNetwork((current) => ({
      ...current,
      connections: current.connections.map((connection) => {
        if (connection.id !== connectionId) return connection;
        if (field === "ap1" || field === "ap2") {
          const other = field === "ap1" ? connection.ap2 : connection.ap1;
          if (value === other) return connection;
        }
        return { ...connection, [field]: value };
      }),
    }));
  }

  function applyConfiguration() {
    const apCount = Number(pendingApCount);
    const connectionCount = Number(pendingConnectionCount);
    const error = validateConfigurationCounts(apCount, connectionCount);
    if (error) {
      setFormError(error);
      setFormMessage("");
      return;
    }

    setNetwork((current) => {
      const accessPoints = current.accessPoints.slice(0, apCount);
      while (accessPoints.length < apCount) {
        const index = accessPoints.length + 1;
        accessPoints.push({
          id: `AP-${String(index).padStart(2, "0")}`,
          signalStrength: 72,
          bandwidth: 65,
          latency: 28,
          interference: 30,
          activeUsers: 24,
        });
      }
      const validIds = new Set(accessPoints.map((ap) => ap.id));
      const connections = current.connections
        .filter((connection) => validIds.has(connection.ap1) && validIds.has(connection.ap2))
        .slice(0, connectionCount);
      while (connections.length < connectionCount) {
        const index = connections.length;
        const ap1 = accessPoints[index % accessPoints.length];
        const ap2 = accessPoints[(index + 1) % accessPoints.length];
        if (!ap1 || !ap2) break;
        connections.push({
          id: `LINK-${String(index + 1).padStart(2, "0")}`,
          ap1: ap1.id,
          ap2: ap2.id,
          distance: 35 + ((index * 13) % 55),
          latency: 15 + ((index * 7) % 25),
          interference: 18 + ((index * 9) % 35),
          signal: 58 + ((index * 11) % 35),
          users: 12 + ((index * 5) % 28),
        });
      }
      return { accessPoints, connections };
    });
    setPendingApCount(String(apCount));
    setPendingConnectionCount(String(connectionCount));
    setFormError("");
    setFormMessage("Network configuration applied and saved on this device.");
  }

  function downloadNetwork() {
    const file = new Blob([buildNetworkText(network)], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(file);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "network.txt";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  function changeView(view: ViewKey) {
    setActiveView(view);
    setFormError("");
  }

  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="brand-lockup">
          <span className="brand-mark"><Network aria-hidden="true" /></span>
          <span className="brand-copy">
            <strong>Mesh<span>Scope</span></strong>
            <small>NETWORK LAB</small>
          </span>
        </div>
        <div className="sidebar-context">
          <span className="context-kicker">WORKSPACE</span>
          <span className="context-title">Campus network</span>
          <span className="context-live"><i /> Simulation active</span>
        </div>
        <nav className="primary-navigation" aria-label="Main navigation">
          <p className="nav-section-label">OPERATIONS</p>
          {navigation.map(({ key, label, icon: Icon }) => (
            <Button
              key={key}
              variant="ghost"
              className={`navigation-button${activeView === key ? " navigation-button--active" : ""}`}
              onClick={() => changeView(key)}
              aria-current={activeView === key ? "page" : undefined}
            >
              <Icon aria-hidden="true" />
              <span>{label}</span>
              {activeView === key ? <ChevronRight className="navigation-chevron" aria-hidden="true" /> : null}
            </Button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <span className="sidebar-footer-icon"><Radio aria-hidden="true" /></span>
          <span><strong>Phase 1</strong><small>Network modeling</small></span>
          <span className="phase-tag">PBL</span>
        </div>
      </aside>

      <div className="app-main">
        <header className="mobile-header">
          <div className="brand-lockup">
            <span className="brand-mark"><Network aria-hidden="true" /></span>
            <span className="brand-copy">
              <strong>Mesh<span>Scope</span></strong>
              <small>NETWORK LAB</small>
            </span>
          </div>
          <span className="context-live"><i /> Simulation</span>
        </header>
        <nav className="mobile-navigation" aria-label="Main navigation">
          {navigation.map(({ key, label, icon: Icon }) => (
            <Button
              key={key}
              variant="ghost"
              className={`mobile-navigation-button${activeView === key ? " mobile-navigation-button--active" : ""}`}
              onClick={() => changeView(key)}
              aria-current={activeView === key ? "page" : undefined}
            >
              <Icon aria-hidden="true" />
              <span>{label}</span>
            </Button>
          ))}
        </nav>

        <div className="topbar">
          <div className="breadcrumbs">
            <span>Campus network</span><ChevronRight aria-hidden="true" /><strong>{navigation.find((item) => item.key === activeView)?.label}</strong>
          </div>
          <div className="topbar-actions">
            <span className="simulation-label"><span className="simulation-pulse" /> SIMULATION</span>
            <Button variant="outline" size="sm" onClick={downloadNetwork}>
              <Download aria-hidden="true" />
              <span>Export network</span>
            </Button>
          </div>
        </div>

        <main className="page-content">
          {activeView === "dashboard" ? (
            <DashboardView
              network={network}
              scoredAccessPoints={scoredAccessPoints}
              healthCounts={healthCounts}
              averageHealth={averageHealth}
              overallStatus={overallStatus}
              totalUsers={totalUsers}
              allIssues={allIssues}
              onOpenView={changeView}
              onSelectAp={setSelectedApId}
            />
          ) : null}
          {activeView === "configure" ? (
            <ConfigureView
              network={network}
              selectedAp={selectedAp}
              selectedApId={selectedApId}
              selectedConnectionId={selectedConnectionId}
              pendingApCount={pendingApCount}
              pendingConnectionCount={pendingConnectionCount}
              formError={formError}
              formMessage={formMessage}
              apIdDrafts={apIdDrafts}
              setSelectedApId={setSelectedApId}
              setSelectedConnectionId={setSelectedConnectionId}
              setPendingApCount={setPendingApCount}
              setPendingConnectionCount={setPendingConnectionCount}
              setApIdDrafts={setApIdDrafts}
              updateAccessPoint={updateAccessPoint}
              updateConnection={updateConnection}
              renameAccessPoint={renameAccessPoint}
              applyConfiguration={applyConfiguration}
            />
          ) : null}
          {activeView === "access-points" ? (
            <AccessPointsView
              scoredAccessPoints={scoredAccessPoints}
              selectedApId={selectedApId}
              onSelectAp={setSelectedApId}
              onConfigure={() => changeView("configure")}
            />
          ) : null}
          {activeView === "topology" ? (
            <TopologyView
              network={network}
              selectedApId={selectedApId}
              selectedConnectionId={selectedConnectionId}
              selectedConnection={selectedConnection}
              getStatus={(ap) => getHealthStatus(calculateHealth(ap))}
              onSelectAp={setSelectedApId}
              onSelectConnection={setSelectedConnectionId}
            />
          ) : null}
          {activeView === "diagnostics" ? (
            <DiagnosticsView scoredAccessPoints={scoredAccessPoints} allIssues={allIssues} onSelectAp={setSelectedApId} />
          ) : null}
          {activeView === "reports" ? (
            <ReportsView
              network={network}
              scoredAccessPoints={scoredAccessPoints}
              averageHealth={averageHealth}
              overallStatus={overallStatus}
              allIssues={allIssues}
              onDownload={downloadNetwork}
            />
          ) : null}
          {activeView === "about" ? <AboutView /> : null}
        </main>
        <footer className="app-footer">
          <span>Campus WiFi Mesh Optimizer</span>
          <span>Phase 1 · Network modeling &amp; health check</span>
          <span className="footer-safe"><ShieldCheck aria-hidden="true" /> Simulated data only</span>
        </footer>
      </div>
    </div>
  );
}

function DashboardView({
  network,
  scoredAccessPoints,
  healthCounts,
  averageHealth,
  overallStatus,
  totalUsers,
  allIssues,
  onOpenView,
  onSelectAp,
}: {
  network: NetworkModel;
  scoredAccessPoints: { ap: AccessPoint; score: number; status: HealthStatus; issues: DiagnosticIssue[] }[];
  healthCounts: { good: number; warning: number; critical: number };
  averageHealth: number;
  overallStatus: HealthStatus;
  totalUsers: number;
  allIssues: { ap: AccessPoint; issue: DiagnosticIssue }[];
  onOpenView: (view: ViewKey) => void;
  onSelectAp: (id: string) => void;
}) {
  return (
    <div className="view-stack">
      <div className="page-intro">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> NETWORK OVERVIEW</p>
          <h1>Campus network health</h1>
          <p className="page-subtitle">A live view of your simulated mesh, access points, and detected issues.</p>
        </div>
        <Button onClick={() => onOpenView("configure")}>
          <SlidersHorizontal aria-hidden="true" />
          Configure network
        </Button>
      </div>

      <section className="metric-grid" aria-label="Network summary">
        <MetricTile label="Total access points" value={network.accessPoints.length} note="in this network" icon={Antenna} />
        <MetricTile label="Wi-Fi connections" value={totalUsers} note="estimated active clients" icon={Wifi} tone="good" />
        <MetricTile
          label="Overall network health"
          value={`${averageHealth.toFixed(0)}%`}
              note={<StatusPill status={overallStatus} />}
          icon={Gauge}
          tone={overallStatus.toLowerCase() as "good" | "warning" | "critical"}
        />
        <MetricTile
          label="Detected issues"
          value={allIssues.length}
          note={`${healthCounts.critical} critical access points`}
          icon={AlertTriangle}
          tone={allIssues.length > 0 ? "warning" : "good"}
          trend={allIssues.length > 0 ? "up" : "down"}
        />
      </section>

      <section className="dashboard-grid dashboard-grid--primary">
        <article className="surface distribution-panel">
          <PanelHeading eyebrow="HEALTH DISTRIBUTION" title="Access point status" detail="Calculated health score across the mesh" />
          <HealthDistribution
            good={healthCounts.good}
            warning={healthCounts.warning}
            critical={healthCounts.critical}
            total={network.accessPoints.length}
          />
          <div className="panel-bottom-note"><Activity aria-hidden="true" /> Status is recalculated as network inputs change.</div>
        </article>
        <article className="surface health-comparison-panel">
          <PanelHeading
            eyebrow="HEALTH COMPARISON"
            title="Access point health"
            detail="Score is clamped to a 0–100 scale"
            action={<Button variant="ghost" size="sm" onClick={() => onOpenView("access-points")}>View all <ChevronRight aria-hidden="true" /></Button>}
          />
          <div className="health-bars">
            {scoredAccessPoints.map(({ ap, score, status }) => (
              <button
                type="button"
                className="health-bar-button"
                key={ap.id}
                onClick={() => {
                  onSelectAp(ap.id);
                  onOpenView("access-points");
                }}
              >
                <HealthBar ap={ap} score={score} status={status} />
              </button>
            ))}
          </div>
        </article>
      </section>

      <section className="dashboard-grid dashboard-grid--secondary">
        <article className="surface alerts-panel">
          <PanelHeading
            eyebrow="DIAGNOSTIC FEED"
            title="Recent alerts"
            detail={`${allIssues.length} findings across ${network.accessPoints.length} access points`}
            action={<Button variant="ghost" size="sm" onClick={() => onOpenView("diagnostics")}>All diagnostics <ChevronRight aria-hidden="true" /></Button>}
          />
          {allIssues.length > 0 ? (
            <div className="alert-list">
              {allIssues.slice(0, 4).map(({ ap, issue }, index) => (
                <button
                  className="alert-row"
                  key={`${ap.id}-${issue.code}`}
                  onClick={() => {
                    onSelectAp(ap.id);
                    onOpenView("access-points");
                  }}
                >
                  <span className={`alert-symbol alert-symbol--${issue.severity}`}><AlertTriangle aria-hidden="true" /></span>
                  <span className="alert-copy"><strong>{issue.title}</strong><small>{ap.id} · {issue.detail}</small></span>
                  <span className="alert-time">{index === 0 ? "NOW" : `${index * 4}m`}</span>
                </button>
              ))}
            </div>
          ) : (
            <div className="empty-state"><CircleCheck aria-hidden="true" /><span>No issues detected in this network.</span></div>
          )}
        </article>
        <article className="surface status-panel">
          <PanelHeading eyebrow="NETWORK STATUS" title="Mesh summary" detail="Current simulated configuration" />
          <div className="status-summary">
            <div className="status-summary-row"><span className="summary-icon summary-icon--blue"><Network aria-hidden="true" /></span><span><small>Mesh connections</small><strong>{network.connections.length} links active</strong></span><span className="status-summary-dot" /></div>
            <div className="status-summary-row"><span className="summary-icon summary-icon--good"><Signal aria-hidden="true" /></span><span><small>Healthy access points</small><strong>{healthCounts.good} of {network.accessPoints.length} good</strong></span><span className="status-summary-dot" /></div>
            <div className="status-summary-row"><span className="summary-icon summary-icon--warning"><AlertTriangle aria-hidden="true" /></span><span><small>Needs attention</small><strong>{healthCounts.warning + healthCounts.critical} access points</strong></span><span className="status-summary-dot status-summary-dot--warning" /></div>
          </div>
          <Button variant="outline" className="status-panel-button" onClick={() => onOpenView("topology")}>
          <MapIcon aria-hidden="true" /> Open topology <ChevronRight aria-hidden="true" />
          </Button>
        </article>
      </section>
    </div>
  );
}

function ConfigureView({
  network,
  selectedAp,
  selectedApId,
  selectedConnectionId,
  pendingApCount,
  pendingConnectionCount,
  formError,
  formMessage,
  apIdDrafts,
  setSelectedApId,
  setSelectedConnectionId,
  setPendingApCount,
  setPendingConnectionCount,
  setApIdDrafts,
  updateAccessPoint,
  updateConnection,
  renameAccessPoint,
  applyConfiguration,
}: {
  network: NetworkModel;
  selectedAp: AccessPoint | undefined;
  selectedApId: string;
  selectedConnectionId: string;
  pendingApCount: string;
  pendingConnectionCount: string;
  formError: string;
  formMessage: string;
  apIdDrafts: Record<string, string>;
  setSelectedApId: (id: string) => void;
  setSelectedConnectionId: (id: string) => void;
  setPendingApCount: (count: string) => void;
  setPendingConnectionCount: (count: string) => void;
  setApIdDrafts: Dispatch<SetStateAction<Record<string, string>>>;
  updateAccessPoint: (apId: string, field: keyof AccessPoint, value: number) => void;
  updateConnection: (connectionId: string, field: keyof NetworkConnection, value: string | number) => void;
  renameAccessPoint: (oldId: string, draft: string) => void;
  applyConfiguration: () => void;
}) {
  return (
    <div className="view-stack">
      <div className="page-intro">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> NETWORK INPUT</p>
          <h1>Configure network</h1>
          <p className="page-subtitle">Adjust access point measurements and mesh links. Changes update scores and diagnostics instantly.</p>
        </div>
      </div>

      <section className="surface configuration-summary">
        <div className="configuration-counts">
          <label className="count-field"><span>Access points</span><input className="field-input" type="number" min={2} max={20} step={1} value={pendingApCount} onChange={(event) => setPendingApCount(event.currentTarget.value)} /></label>
          <label className="count-field"><span>Connections</span><input className="field-input" type="number" min={1} max={50} step={1} value={pendingConnectionCount} onChange={(event) => setPendingConnectionCount(event.currentTarget.value)} /></label>
          <Button onClick={applyConfiguration}><Check aria-hidden="true" /> Apply configuration</Button>
        </div>
        {formError ? <p className="form-feedback form-feedback--error" role="alert"><CircleAlert aria-hidden="true" />{formError}</p> : null}
        {formMessage ? <p className="form-feedback form-feedback--success" role="status"><CircleCheck aria-hidden="true" />{formMessage}</p> : null}
      </section>

      <section className="configuration-layout">
        <article className="surface ap-editor-panel">
          <PanelHeading eyebrow="ACCESS POINTS" title="AP measurements" detail="Choose an access point to edit its inputs." />
          <div className="ap-selector-list" role="tablist" aria-label="Select access point">
            {network.accessPoints.map((ap) => (
              <button
                type="button"
                role="tab"
                aria-selected={ap.id === selectedApId}
                className={`ap-selector${ap.id === selectedApId ? " ap-selector--active" : ""}`}
                key={ap.id}
                onClick={() => setSelectedApId(ap.id)}
              >
                <span className="ap-selector-dot" />
                <span>{ap.id}</span>
                <ChevronRight aria-hidden="true" />
              </button>
            ))}
          </div>
          {selectedAp ? (
            <div className="ap-editor">
              <div className="editor-ap-heading"><span className="editor-ap-icon"><Antenna aria-hidden="true" /></span><div><strong>{selectedAp.id}</strong><small>Access point parameters</small></div><StatusPill status={getHealthStatus(calculateHealth(selectedAp))} /></div>
              <label className="field-wrap ap-id-field"><span className="field-label">AP ID</span><input className="field-input" value={apIdDrafts[selectedAp.id] ?? selectedAp.id} onChange={(event) => setApIdDrafts((drafts) => ({ ...drafts, [selectedAp.id]: event.currentTarget.value }))} onBlur={() => renameAccessPoint(selectedAp.id, apIdDrafts[selectedAp.id] ?? selectedAp.id)} /></label>
              <div className="metric-fields-grid">
                <NumberField label="Signal strength" value={selectedAp.signalStrength} max={100} suffix="%" onChange={(value) => updateAccessPoint(selectedAp.id, "signalStrength", value)} />
                <NumberField label="Bandwidth" value={selectedAp.bandwidth} max={100} suffix="Mbps" onChange={(value) => updateAccessPoint(selectedAp.id, "bandwidth", value)} />
                <NumberField label="Latency" value={selectedAp.latency} max={100} suffix="ms" onChange={(value) => updateAccessPoint(selectedAp.id, "latency", value)} />
                <NumberField label="Interference" value={selectedAp.interference} max={100} suffix="%" onChange={(value) => updateAccessPoint(selectedAp.id, "interference", value)} />
                <NumberField label="Active users" value={selectedAp.activeUsers} max={2000} suffix="users" onChange={(value) => updateAccessPoint(selectedAp.id, "activeUsers", value)} />
              </div>
              <div className="editor-score-row"><span>Calculated health</span><strong>{calculateHealth(selectedAp).toFixed(1)}<small> / 100</small></strong></div>
              {getDiagnostics(selectedAp).length > 0 ? <div className="editor-issues"><span className="field-label">DETECTED ISSUES</span><div>{getDiagnostics(selectedAp).map((issue) => <IssueBadge key={issue.code} issue={issue} />)}</div></div> : null}
            </div>
          ) : null}
        </article>

        <article className="surface connections-panel">
          <PanelHeading eyebrow="MESH LINKS" title="Connections" detail={`${network.connections.length} configured connections`} />
          <div className="connection-list">
            {network.connections.map((connection) => (
              <div className="connection-editor" key={connection.id}>
                <div className="connection-editor-heading"><span className="connection-code"><Link2 aria-hidden="true" />{connection.id}</span><span className="connection-route">{connection.ap1}<span>—</span>{connection.ap2}</span></div>
                <div className="connection-ap-fields">
                  <label className="field-wrap"><span className="field-label">AP1</span><select className="field-input" value={connection.ap1} onChange={(event) => updateConnection(connection.id, "ap1", event.currentTarget.value)}>{network.accessPoints.filter((ap) => ap.id !== connection.ap2).map((ap) => <option key={ap.id} value={ap.id}>{ap.id}</option>)}</select></label>
                  <label className="field-wrap"><span className="field-label">AP2</span><select className="field-input" value={connection.ap2} onChange={(event) => updateConnection(connection.id, "ap2", event.currentTarget.value)}>{network.accessPoints.filter((ap) => ap.id !== connection.ap1).map((ap) => <option key={ap.id} value={ap.id}>{ap.id}</option>)}</select></label>
                </div>
                <div className="connection-metrics-grid">
                  <NumberField label="Distance" value={connection.distance} max={5000} suffix="m" onChange={(value) => updateConnection(connection.id, "distance", value)} />
                  <NumberField label="Latency" value={connection.latency} max={100} suffix="ms" onChange={(value) => updateConnection(connection.id, "latency", value)} />
                  <NumberField label="Interference" value={connection.interference} max={100} suffix="%" onChange={(value) => updateConnection(connection.id, "interference", value)} />
                  <NumberField label="Signal" value={connection.signal} max={100} suffix="%" onChange={(value) => updateConnection(connection.id, "signal", value)} />
                  <NumberField label="Users" value={connection.users} max={2000} onChange={(value) => updateConnection(connection.id, "users", value)} />
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}

function AccessPointsView({
  scoredAccessPoints,
  selectedApId,
  onSelectAp,
  onConfigure,
}: {
  scoredAccessPoints: { ap: AccessPoint; score: number; status: HealthStatus; issues: DiagnosticIssue[] }[];
  selectedApId: string;
  onSelectAp: (id: string) => void;
  onConfigure: () => void;
}) {
  const selected = scoredAccessPoints.find((item) => item.ap.id === selectedApId) ?? scoredAccessPoints[0];
  return (
    <div className="view-stack">
      <div className="page-intro">
        <div><p className="eyebrow"><span className="eyebrow-line" /> INVENTORY</p><h1>Access points</h1><p className="page-subtitle">Health scores and diagnostics for every modeled access point.</p></div>
        <Button variant="outline" onClick={onConfigure}><Settings2 aria-hidden="true" /> Edit inputs</Button>
      </div>
      <div className="access-point-layout">
        <section className="surface access-point-list-panel">
          <PanelHeading eyebrow="ACCESS POINT INVENTORY" title={`${scoredAccessPoints.length} access points`} detail="Select one to inspect its measurements" />
          <div className="ap-inventory-list">
            {scoredAccessPoints.map(({ ap, score, status, issues }) => (
              <button type="button" className={`ap-inventory-row${ap.id === selectedApId ? " ap-inventory-row--active" : ""}`} key={ap.id} onClick={() => onSelectAp(ap.id)}>
                <span className={`ap-status-marker ap-status-marker--${status.toLowerCase()}`}><Antenna aria-hidden="true" /></span>
                <span className="ap-inventory-main"><strong>{ap.id}</strong><small>{issues.length ? `${issues.length} detected issue${issues.length === 1 ? "" : "s"}` : "No detected issues"}</small></span>
                <span className="ap-inventory-score"><strong>{score.toFixed(0)}</strong><small>HEALTH</small></span>
                <StatusPill status={status} />
              </button>
            ))}
          </div>
        </section>
        {selected ? (
          <section className="surface ap-detail-panel">
            <div className="ap-detail-top"><span className={`ap-detail-icon ap-detail-icon--${selected.status.toLowerCase()}`}><Antenna aria-hidden="true" /></span><div><p className="eyebrow">ACCESS POINT DETAIL</p><h2>{selected.ap.id}</h2></div><StatusPill status={selected.status} /></div>
            <div className="detail-health-score"><span>Health score</span><strong className={`health-text--${selected.status.toLowerCase()}`}>{selected.score.toFixed(1)}<small> / 100</small></strong><div className="health-bar-track"><div className={`health-bar-fill health-bar-fill--${selected.status.toLowerCase()}`} style={{ width: `${selected.score}%` }} /></div></div>
            <div className="detail-metrics-grid">
              {[
                { label: "Signal strength", value: `${selected.ap.signalStrength}%`, icon: Signal },
                { label: "Bandwidth", value: `${selected.ap.bandwidth} Mbps`, icon: Wifi },
                { label: "Latency", value: `${selected.ap.latency} ms`, icon: Activity },
                { label: "Interference", value: `${selected.ap.interference}%`, icon: Radio },
                { label: "Active users", value: selected.ap.activeUsers, icon: Gauge },
              ].map(({ label, value, icon: Icon }) => <div className="detail-metric" key={label}><Icon aria-hidden="true" /><span><small>{label}</small><strong>{value}</strong></span></div>)}
            </div>
            <div className="detail-issues"><h3>Detected issues</h3>{selected.issues.length ? selected.issues.map((issue) => <div className="detail-issue" key={issue.code}><IssueBadge issue={issue} /><p>{issue.detail}</p></div>) : <div className="empty-state empty-state--compact"><CircleCheck aria-hidden="true" />No issues detected for this access point.</div>}</div>
          </section>
        ) : null}
      </div>
    </div>
  );
}

function TopologyView({
  network,
  selectedApId,
  selectedConnectionId,
  selectedConnection,
  getStatus,
  onSelectAp,
  onSelectConnection,
}: {
  network: NetworkModel;
  selectedApId: string;
  selectedConnectionId: string;
  selectedConnection: NetworkConnection | undefined;
  getStatus: (ap: AccessPoint) => HealthStatus;
  onSelectAp: (id: string) => void;
  onSelectConnection: (id: string) => void;
}) {
  const selectedAp = network.accessPoints.find((ap) => ap.id === selectedApId);
  return (
    <div className="view-stack">
      <div className="page-intro"><div><p className="eyebrow"><span className="eyebrow-line" /> MESH MAP</p><h1>Topology visualization</h1><p className="page-subtitle">Inspect modeled access points and select a link to see its connection details.</p></div><span className="topology-count"><Network aria-hidden="true" />{network.accessPoints.length} nodes <i /> {network.connections.length} links</span></div>
      <section className="surface topology-panel">
        <PanelHeading eyebrow="CAMPUS MESH" title="Network topology" detail="Node positions are arranged for visibility; they do not represent a physical campus map." />
        <TopologyCanvas accessPoints={network.accessPoints} connections={network.connections} selectedApId={selectedApId} selectedConnectionId={selectedConnectionId} getStatus={getStatus} onSelectAp={onSelectAp} onSelectConnection={onSelectConnection} />
      </section>
      <section className="topology-detail-grid">
        <article className="surface topology-detail-panel">
          <PanelHeading eyebrow="SELECTED NODE" title={selectedAp?.id ?? "Access point"} detail="Current health and detected issues" />
          {selectedAp ? <div className="selected-node-summary"><StatusPill status={getStatus(selectedAp)} /><strong>{calculateHealth(selectedAp).toFixed(1)}<small> / 100 health</small></strong><span>{getDiagnostics(selectedAp).length ? `${getDiagnostics(selectedAp).length} issue(s) detected` : "No detected issues"}</span></div> : null}
        </article>
        <article className="surface topology-detail-panel">
          <PanelHeading eyebrow="SELECTED LINK" title={selectedConnection?.id ?? "Choose a connection"} detail={selectedConnection ? `${selectedConnection.ap1} connected to ${selectedConnection.ap2}` : "Select an edge on the map to inspect it."} />
          {selectedConnection ? <div className="connection-detail-metrics"><span><small>Distance</small><strong>{selectedConnection.distance} m</strong></span><span><small>Latency</small><strong>{selectedConnection.latency} ms</strong></span><span><small>Signal</small><strong>{selectedConnection.signal}%</strong></span><span><small>Interference</small><strong>{selectedConnection.interference}%</strong></span><span><small>Users</small><strong>{selectedConnection.users}</strong></span></div> : null}
        </article>
      </section>
    </div>
  );
}

function DiagnosticsView({
  scoredAccessPoints,
  allIssues,
  onSelectAp,
}: {
  scoredAccessPoints: { ap: AccessPoint; score: number; status: HealthStatus; issues: DiagnosticIssue[] }[];
  allIssues: { ap: AccessPoint; issue: DiagnosticIssue }[];
  onSelectAp: (id: string) => void;
}) {
  const criticalCount = allIssues.filter(({ issue }) => issue.severity === "critical").length;
  const warningCount = allIssues.length - criticalCount;
  return (
    <div className="view-stack">
      <div className="page-intro"><div><p className="eyebrow"><span className="eyebrow-line" /> HEALTH CHECK</p><h1>Network diagnostics</h1><p className="page-subtitle">Rule-based findings from the measurements entered for each access point.</p></div></div>
      <section className="diagnostic-summary-grid">
        <div className="diagnostic-summary-tile"><span className="summary-icon summary-icon--critical"><ShieldAlert aria-hidden="true" /></span><span><small>Critical findings</small><strong>{criticalCount}</strong></span></div>
        <div className="diagnostic-summary-tile"><span className="summary-icon summary-icon--warning"><AlertTriangle aria-hidden="true" /></span><span><small>Warning findings</small><strong>{warningCount}</strong></span></div>
        <div className="diagnostic-summary-tile"><span className="summary-icon summary-icon--good"><ShieldCheck aria-hidden="true" /></span><span><small>Clear access points</small><strong>{scoredAccessPoints.filter((item) => item.issues.length === 0).length}</strong></span></div>
      </section>
      <section className="surface diagnostics-panel">
        <PanelHeading eyebrow="DIAGNOSTIC RESULTS" title="Findings by access point" detail={`${allIssues.length} total findings across ${scoredAccessPoints.length} access points`} />
        {scoredAccessPoints.map(({ ap, score, status, issues }) => (
          <article className="diagnostic-ap-group" key={ap.id}>
            <button className="diagnostic-ap-heading" onClick={() => onSelectAp(ap.id)}>
              <span className={`ap-status-marker ap-status-marker--${status.toLowerCase()}`}><Antenna aria-hidden="true" /></span>
              <span><strong>{ap.id}</strong><small>Health score {score.toFixed(1)}</small></span>
              <StatusPill status={status} />
              <ChevronRight aria-hidden="true" />
            </button>
            {issues.length ? <div className="diagnostic-issue-list">{issues.map((issue) => <div className={`diagnostic-issue-row diagnostic-issue-row--${issue.severity}`} key={issue.code}><span className={`alert-symbol alert-symbol--${issue.severity}`}><AlertTriangle aria-hidden="true" /></span><span><strong>{issue.title}</strong><small>{issue.detail}</small></span><span className="severity-label">{issue.severity}</span></div>)}</div> : <div className="diagnostic-clear-row"><CircleCheck aria-hidden="true" /> No issues detected for this access point.</div>}
          </article>
        ))}
      </section>
    </div>
  );
}

function ReportsView({
  network,
  scoredAccessPoints,
  averageHealth,
  overallStatus,
  allIssues,
  onDownload,
}: {
  network: NetworkModel;
  scoredAccessPoints: { ap: AccessPoint; score: number; status: HealthStatus; issues: DiagnosticIssue[] }[];
  averageHealth: number;
  overallStatus: HealthStatus;
  allIssues: { ap: AccessPoint; issue: DiagnosticIssue }[];
  onDownload: () => void;
}) {
  return (
    <div className="view-stack">
      <div className="page-intro"><div><p className="eyebrow"><span className="eyebrow-line" /> NETWORK REPORT</p><h1>Reports &amp; export</h1><p className="page-subtitle">Review the current model and download a text file generated from its live values.</p></div><Button onClick={onDownload}><Download aria-hidden="true" /> Download network.txt</Button></div>
      <section className="report-overview-grid">
        <div className="report-overview-tile"><span>ACCESS POINTS</span><strong>{network.accessPoints.length}</strong><small>n</small></div>
        <div className="report-overview-tile"><span>CONNECTIONS</span><strong>{network.connections.length}</strong><small>e</small></div>
        <div className="report-overview-tile"><span>AVERAGE HEALTH</span><strong>{averageHealth.toFixed(1)}<small>%</small></strong><StatusPill status={overallStatus} /></div>
        <div className="report-overview-tile"><span>DETECTED ISSUES</span><strong>{allIssues.length}</strong><small>across the mesh</small></div>
      </section>
      <section className="surface report-table-panel">
        <PanelHeading eyebrow="CONFIGURATION SUMMARY" title="Access point report" detail="Measurements, calculated score, status, and detected problems." />
        <div className="report-table-scroll"><table className="report-table"><thead><tr><th>AP ID</th><th>Signal</th><th>Bandwidth</th><th>Latency</th><th>Interference</th><th>Users</th><th>Health</th><th>Status</th><th>Issues</th></tr></thead><tbody>{scoredAccessPoints.map(({ ap, score, status, issues }) => <tr key={ap.id}><td className="mono-cell">{ap.id}</td><td>{ap.signalStrength}%</td><td>{ap.bandwidth} Mbps</td><td>{ap.latency} ms</td><td>{ap.interference}%</td><td>{ap.activeUsers}</td><td className={`mono-cell health-text--${status.toLowerCase()}`}>{score.toFixed(1)}</td><td><StatusPill status={status} /></td><td>{issues.length}</td></tr>)}</tbody></table></div>
      </section>
      <section className="surface report-table-panel">
        <PanelHeading eyebrow="LINK DETAILS" title="Mesh connection report" detail="Every configured edge is included in the export." />
        <div className="report-table-scroll"><table className="report-table"><thead><tr><th>Link ID</th><th>AP1</th><th>AP2</th><th>Distance</th><th>Latency</th><th>Interference</th><th>Signal</th><th>Users</th></tr></thead><tbody>{network.connections.map((connection) => <tr key={connection.id}><td className="mono-cell">{connection.id}</td><td>{connection.ap1}</td><td>{connection.ap2}</td><td>{connection.distance} m</td><td>{connection.latency} ms</td><td>{connection.interference}%</td><td>{connection.signal}%</td><td>{connection.users}</td></tr>)}</tbody></table></div>
      </section>
      <section className="surface export-format-panel">
        <div className="export-format-copy"><span className="export-file-icon"><Download aria-hidden="true" /></span><span><strong>network.txt</strong><small>Generated from the current saved configuration.</small></span></div>
        <code>{network.accessPoints.length} {network.connections.length} · AP rows: ID, signal, bandwidth, latency, interference, users, health · Link rows: AP1, AP2, distance, latency, interference, signal, users</code>
        <Button variant="outline" onClick={onDownload}><Download aria-hidden="true" /> Export file</Button>
      </section>
    </div>
  );
}

function AboutView() {
  return (
    <div className="view-stack">
      <div className="page-intro"><div><p className="eyebrow"><span className="eyebrow-line" /> PROJECT DETAILS</p><h1>About the project</h1><p className="page-subtitle">Project scope and Phase 1 deliverables.</p></div></div>
      <section className="surface about-project-panel">
        <div className="about-project-mark"><Network aria-hidden="true" /><span>PHASE 1 · PBL</span></div>
        <div className="about-project-content"><p className="eyebrow">SEMESTER 3 · COMPUTER SCIENCE</p><h2>Campus WiFi Mesh<br />Topology Optimizer</h2><p className="about-description">An academic project demonstration for modeling campus access points, calculating network health, identifying common issues, and generating a structured network report.</p>
          <div className="project-facts"><div><small>Academic project</small><strong>Semester 3 PBL</strong></div><div><small>Project phase</small><strong>Phase 1: Network Modeling &amp; Health Check</strong></div><div><small>Module 1</small><strong>Input, health calculation, diagnostics, export</strong></div></div>
        </div>
      </section>
      <section className="about-scope-grid"><article className="surface about-scope-item"><span className="scope-icon"><SlidersHorizontal aria-hidden="true" /></span><h3>Network input</h3><p>Configure 2–20 access points and 1–50 connections with editable measurements.</p></article><article className="surface about-scope-item"><span className="scope-icon scope-icon--good"><Gauge aria-hidden="true" /></span><h3>Health check</h3><p>Calculate per-access-point health scores and classify network status.</p></article><article className="surface about-scope-item"><span className="scope-icon scope-icon--warning"><ShieldAlert aria-hidden="true" /></span><h3>Problem detection</h3><p>Highlight weak signal, high latency, interference, and user load.</p></article><article className="surface about-scope-item"><span className="scope-icon scope-icon--blue"><Download aria-hidden="true" /></span><h3>Network report</h3><p>Export the configured network and calculated health to network.txt.</p></article></section>
      <div className="simulation-disclaimer"><ShieldCheck aria-hidden="true" /><p><strong>Simulation only.</strong> Values are user-provided or sample data; this application does not monitor real campus Wi-Fi devices.</p></div>
    </div>
  );
}